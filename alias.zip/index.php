	<?php  include("part/head.php") ?>
	<body>
	<div id="fh5co-page">
		<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>

		<?php  include("part/menu-nav.php") ?>

		<div id="fh5co-main">
			
			<?php  include("home.php") ?>	

		</div>
	</div>

	<?php  include("part/script.php") ?>

	</body>
</html>

